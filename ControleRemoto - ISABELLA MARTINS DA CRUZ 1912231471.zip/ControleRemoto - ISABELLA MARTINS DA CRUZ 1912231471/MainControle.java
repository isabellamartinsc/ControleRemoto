public class MainControle {

    public static void main(String[] args) {
        ControleRemoto c = new ControleRemoto();

        c.maisVolume();
        c.maisVolume();
        c.menosVolume();
        c.ligarMudo();
        c.desligarMudo();
        c.abrirMenu();
        c.fecharMenu();
        c.play();
        c.pause();
        c.desligar();
    


    }
}